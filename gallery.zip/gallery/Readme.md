# IDM3 Sample Intellij Project

## Introduction
This repo contains a sample Intellij project with a Docker container deployment configuration. 

## Requirements

Install the following software:
* Intellij Ultimate Edition 2024 (https://www.jetbrains.com/idea/)  
* Docker-desktop (https://docs.docker.com/docker-for-windows/)
* Git (https://git-scm.com/)

