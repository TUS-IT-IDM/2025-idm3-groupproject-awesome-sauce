package idm3.project.gallery;

import idm3.project.gallery.application.GalleryApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class GalleryApplicationTests {

    @Test
    void contextLoads() {
    }

    }
